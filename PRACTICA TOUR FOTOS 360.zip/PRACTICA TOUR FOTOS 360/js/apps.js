var panorama, viewer, container, infospot;

container = document.querySelector('#container_principal');
panorama = new PANOLENS.ImagePanorama('imagenes/iglesia.jpg');

// zona de interacción 1
var infospot1 = new PANOLENS.Infospot(30, 'imagenes/info.jpg');
infospot1.position.set(0, 0, -600);
infospot1.addHoverText("Entrada lateral izquierda. Esta puerta es de madera rustica con herrajes forjados estilo Barroco. Este estilo se caracteriza por su exuberancia, dramatismo y emotividad, buscando transmitir la fe de una manera intensa y llena de vida. El estilo barroco surgió como respuesta a la Reforma Protestante. La Iglesia Católica buscaba revitalizar la fe y atraer a los fieles a través del arte y la arquitectura.\".", -60);
infospot1.element.innerHTML = '<div style="background-color: rgba(0, 0, 0, 0.8); color:#fff; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">Entrada lateral izquierda. Esta puerta es de madera rustica con herrajes forjados estilo Barroco. Este estilo se caracteriza por su exuberancia, dramatismo y emotividad, buscando transmitir la fe de una manera intensa y llena de vida. El estilo barroco surgió como respuesta a la Reforma Protestante. La Iglesia Católica buscaba revitalizar la fe y atraer a los fieles a través del arte y la arquitectura".</div>';
panorama.add(infospot1);


// Zona de interacción 2
var infospot2 = new PANOLENS.Infospot(30, 'imagenes/info2.jpg');
infospot2.position.set(500, 150, -9);
infospot2.addHoverText("La parte de la iglesia que se muestra en la imagen es el altar mayor. Está decorado con elementos barrocos como columnas de mármol, candelabros y estatuas. En el centro del altar hay una representación de la crucifixión de Jesús. Los vitrales a los lados permiten la entrada de luz natural, iluminando el espacio de manera colorida. La arquitectura del techo también es notable, con detalles ornamentales y arcos que enmarcan el altar.", -60);
infospot2.element.innerHTML = '<div style="background-color: rgba(0,0,255,0.8); color:#fff; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">La parte de la iglesia que se muestra en la imagen es el altar mayor. Está decorado con elementos barrocos como columnas de mármol, candelabros y estatuas. En el centro del altar hay una representación de la crucifixión de Jesús. Los vitrales a los lados permiten la entrada de luz natural, iluminando el espacio de manera colorida. La arquitectura del techo también es notable, con detalles ornamentales y arcos que enmarcan el altar.</div>';
panorama.add(infospot2);


// Zona de interacción 4
var infospot4 = new PANOLENS.Infospot(50, 'imagenes/musica.jpg');
infospot4.position.set(500, 10, 100);
infospot4.addHoverText('audio de canticos', -60);
infospot4.element.innerHTML = '<div style="background-color: rgba(69, 148, 208, 1); color:#fff; border-radius: 5px; padding: 5px; font-size: 14px; width: 310px;"><audio controls><source src="audios/audio1.mp3" type="audio/mpeg"></audio></;">Audio de Canticos.</div>';
panorama.add(infospot4);


// Zona de interacción 3
var infospot3 = new PANOLENS.Infospot(300, 'imagenes/info3.jpg'); 
infospot3.position.set(-4500, -650, -3500);
infospot3.addHoverText("Conjunto de libros de lectura que se conoce como biblia o diccionarios biblicos. En algunas iglesias se acostubra dejarlas en bancas para que las personas que no tienen pueden usarlas.", -60);
infospot3.element.innerHTML = '<div style="background-color: rgba(69, 148, 208, 1); color:#fff; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">Conjunto de libros de lectura que se conoce como biblia o diccionarios biblicos. En algunas iglesias se acostubra dejarlos en las bancas para que las personas que no tienen pueden usarlas.</div>';
panorama.add(infospot3);


//zona de interaccion 5
var infospot5 = new PANOLENS.Infospot(60, 'imagenes/video.jpg'); 
infospot5.position.set(500, 60, 520);
infospot5.addHoverText("La biblioteca multimedia ofrece una opción de procesamiento, almacenamiento y transmisión de medios para todos los materiales de audio y video. Utilice la biblioteca multimedia para crear, ver, editar y administrar todo el contenido de audio y video.", 60);
infospot5.element.innerHTML = '<div class="" style=""></div> <iframe width="720" height="480" src="https://www.youtube.com/embed/G5xxT55Mx6M"></iframe>';
panorama.add(infospot5);


//zona de interaccion 6
var infospot6 = new PANOLENS.Infospot(5, 'imagenes/info6.jpg'); 
infospot6.position.set (0, 0, 90);
infospot6.addHoverText("Muchas iglesias tienen capillas laterales dedicadas a diferentes objetivos. Los confesionarios suelen ubicarse en estas capillas, a menudo en una zona separada para mayor privacidad.", -60);
infospot6.element.innerHTML = '<div style="background-color: rgba(69, 148, 208, 1); color:#fff; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">Muchas iglesias tienen capillas laterales dedicadas para distintos objetivos. Los confesionarios suelen ubicarse en estas capillas, a menudo en una zona separada para mayor privacidad..</div>';
panorama.add(infospot6);


//zona de interaccion 7
var infospot7 = new PANOLENS.Infospot(300, 'imagenes/info7.jpg'); 
infospot7.position.set (-1000, 300, -2200);
infospot7.addHoverText("Objeto muy valioso, se puede decir que es como reliquia. En este escenario sirve para donaciones de dinero o peticiones. Es una especie de caja fuerte artesanal con una ranura en la parte superior para depositar dinero o papeles. En la parte frontal tiene una puerta  con una cerradura. La caja está decorada con detalles tallados. Se encuentra en un lugar visible y accesible para los fieles. Algunas iglesias tienen varias de estas cajas en diferentes áreas del edificio.", -60);
infospot7.element.innerHTML = '<div style="background-color: rgba(69, 148, 208, 1); color:#fff; border-radius: 5px; padding: 10px; font-size: 14px; width: 200px;">Objeto muy valioso, se puede decir que es como reliquia. En este escenario sirve para donaciones de dinero o peticiones. Es una especie de caja fuerte artesanal con una ranura en la parte superior para depositar dinero o papeles. En la parte frontal tiene una puerta  con una cerradura. La caja está decorada con detalles tallados. Se encuentra en un lugar visible y accesible para los fieles. Algunas iglesias tienen varias de estas cajas en diferentes áreas del edificio.</div>';
panorama.add(infospot7);


viewer = new PANOLENS.Viewer({container: container });
viewer.add(panorama);



